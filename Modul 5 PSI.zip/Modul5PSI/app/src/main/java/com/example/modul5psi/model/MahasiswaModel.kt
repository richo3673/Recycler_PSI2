package com.example.modul5psi.model

class MahasiswaModel(var nama: String, var nim: String, var kelas: String) {
}