package com.example.modul5psi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.constraintlayout.helper.widget.Carousel.Adapter
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.modul5psi.helper.MahasiswaAdapter
import com.example.modul5psi.model.MahasiswaModel
import com.example.modul5psi.viewmodel.MahasiswaViewModel

class MainActivity : AppCompatActivity() {
    var data = MutableLiveData<List<MahasiswaModel>>()
    lateinit var da: List<MahasiswaModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        val model = ViewModelProvider(this).get(MahasiswaViewModel::class.java)
        model.getMahasiswaList().observe(this, Observer { mahasiswaListData ->
            data.value = mahasiswaListData
            da = mahasiswaListData!!
            recyclerView.adapter = MahasiswaAdapter(data, this)
        })
    }
}