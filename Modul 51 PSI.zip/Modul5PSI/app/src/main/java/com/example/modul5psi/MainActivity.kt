package com.example.modul5psi

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.modul5psi.databinding.ActivityMainBinding
import com.example.modul5psi.helper.MahasiswaAdapter
import com.example.modul5psi.model.MahasiswaModel
import com.example.modul5psi.viewmodel.MahasiswaViewModel


class MainActivity : AppCompatActivity(), View.OnClickListener {
    var data = MutableLiveData<List<MahasiswaModel>>()
    lateinit var da: List<MahasiswaModel>
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        val model = ViewModelProvider(this).get(MahasiswaViewModel::class.java)
        model.getMahasiswaList().observe(this, Observer { mahasiswaListData ->
            data.value = mahasiswaListData
            da = mahasiswaListData!!
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = MahasiswaAdapter(data, this)
        })
        binding.fab.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.fab -> FormDialogFragment().show(supportFragmentManager, FormDialogFragment.TAG)
        }
    }
}