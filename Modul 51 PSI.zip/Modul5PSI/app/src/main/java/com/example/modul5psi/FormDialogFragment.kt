package com.example.modul5psi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.DialogFragment


class FormDialogFragment : DialogFragment() {
    private var toolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.AppTheme_FullScreenDialog)
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            val width = ViewGroup.LayoutParams.MATCH_PARENT
            val height = ViewGroup.LayoutParams.MATCH_PARENT
            dialog.window!!.setLayout(width, height)

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val view: View = inflater.inflate(R.layout.form_dialog, container, false)
        toolbar = view.findViewById(R.id.toolbar)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(requireView(), savedInstanceState)
        toolbar!!.setNavigationOnClickListener { v: View? ->
            dismiss()
        }
        toolbar!!.title = "Some Title"
        toolbar!!.inflateMenu(R.menu.form_dialog)
        toolbar!!.setOnMenuItemClickListener { item: MenuItem? ->
            Toast.makeText(requireContext(), "Berhasil", Toast.LENGTH_SHORT).show()
            dismiss()
            true
        }
    }

    companion object {
        const val TAG = "PurchaseConfirmationDialog"
    }
}

//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
//        val inputNama = EditText(requireContext())
//        val inputNIM = EditText(requireContext())
//        val inputKelas = EditText(requireContext())
//
//        return MaterialAlertDialogBuilder(requireContext())
//            .setTitle("Tambah Mahasiswa")
//            .setMessage("Harap masukkan seluruh informasi dengan benar.")
//            .setPositiveButton(
//                "Simpan"
//            ) { dialogInterface, i ->
//            }
//            .setNegativeButton(
//                "CANCEL"
//            ) { dialogInterface, i -> }
//            .show()
//    }
//

//}