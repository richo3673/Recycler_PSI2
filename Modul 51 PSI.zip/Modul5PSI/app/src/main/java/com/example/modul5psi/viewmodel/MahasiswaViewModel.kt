package com.example.modul5psi.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.modul5psi.model.MahasiswaModel

class MahasiswaViewModel: ViewModel() {

    var mahasiswaListData : MutableLiveData<ArrayList<MahasiswaModel>>? = null

    internal fun getMahasiswaList():MutableLiveData<ArrayList<MahasiswaModel>> {
        if(mahasiswaListData ==  null) {
            mahasiswaListData = MutableLiveData()
            addMahasiswa()
        }
        return mahasiswaListData as MutableLiveData<ArrayList<MahasiswaModel>>
    }

    private fun addMahasiswa() {
        val mahasiswaList = ArrayList<MahasiswaModel>()
        mahasiswaList.add(MahasiswaModel("Richo Wijaya Putra", "205150200111018", "PSI-A"))
        mahasiswaList.add(MahasiswaModel("Erling Haaland", "205150200110123", "MPPI-G"))
        mahasiswaListData!!.postValue(mahasiswaList)
    }


}